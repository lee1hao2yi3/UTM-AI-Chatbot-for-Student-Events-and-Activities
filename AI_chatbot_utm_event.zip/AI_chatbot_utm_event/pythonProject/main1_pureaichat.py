from flask import Flask, render_template, request, jsonify, Blueprint
from flask_cors import CORS
from dotenv import load_dotenv
import os
import json
from openai import OpenAI

# Load environment variables
load_dotenv()
OPEN_AI_API_KEY = os.getenv("OPEN_AI_API_KEY")
client = OpenAI(api_key=OPEN_AI_API_KEY)

# Load activity information from JSON file
with open("C:/Users/leele/Downloads/AttractiveChatbot-main/AttractiveChatbot-main/pythonProject/activities.json", 'r') as f: 
    activity_data = json.load(f)

app_blueprint = Blueprint('app', __name__, template_folder='../Html')

@app_blueprint.route('/')
def index():
    return render_template('chatbot.html')

app = Flask(__name__, static_folder='../static')
CORS(app)  # This will enable CORS for all routes

# Register the Blueprint
app.register_blueprint(app_blueprint)


@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()

    if not data or 'message' not in data:
        return jsonify({'error': 'Invalid request'}), 400

    user_message = data['message']

    try:
        # Check for farewell or feedback-related keywords
        farewell_keywords = ["bye", "goodbye", "feedback"]
        if any(keyword in user_message.lower() for keyword in farewell_keywords):
            feedback_response = (
                "Thank you for chatting with us! We're always striving to improve. "
                "If you have a moment, please provide your valuable feedback through the following link: "
                '<a href="https://forms.gle/K2aUEjvMEkJof8pa7" target="_blank">Feedback Form</a>. '
                "Have a great day!"
            )
            return jsonify({'response': feedback_response})

        # Check for activity-related queries
        if any(keyword in user_message.lower() for keyword in ["activity", "event", "upcoming", "schedule", "club"]):
            # Prepare context for OpenAI 
            context_string = "Here are some upcoming student activities at UTM:\n"
            for activity in activity_data:
                context_string += f"- {activity['activity_name']} by {activity['club_society']}: {activity['description']}\n"
                context_string += f"  Date: {activity['date']}, Time: {activity['time']}\n"
                context_string += f"  Location: {activity['location']}\n"
                context_string += f"  Registration: {activity['registration_link']}\n\n"
                ##context_string += f"  Registration: {activity['registration_link']}\n\n"
                #print("Debug Context String Sent to OpenAI:\n", context_string)

            # Initial response with limited max_tokens
            response = client.chat.completions.create(
                model="gpt-4o-mini",  # Use the GPT-4 turbo model (replace if needed)
                messages=[
                    {"role": "system", "content": context_string},
                    {"role": "user", "content": user_message}
                ],
                max_tokens=500,  # Adjust this value as needed
                temperature=0.7
            )
            chat_response = response.choices[0].message.content.strip()
            chat_response = chat_response.replace('\n', '<br>')
            #print("Debug AI Response Before Truncating:\n", chat_response)  

            # Check if response exceeds max_tokens and truncate if necessary
            if len(chat_response) > 500:  # Adjust threshold as needed
                truncated_response = chat_response[:500] + "..."
                response_with_prompt = f"{truncated_response}\n\nWould you like to see more details or search for other activities?"
                return jsonify({'response': response_with_prompt})
            else:
                # Format activities with newlines before returning
                formatted_activities = format_activities(activity_data)
                #print("Debug Formatted Activities Response:\n", formatted_activities)
                #formatted_activities = formatted_activities.replace("\n", "<br>")
                return jsonify({'response': formatted_activities})

        else:
            # Handle general queries about UTM without activity-specific context
            response = client.chat.completions.create(
                model="gpt-4o-mini",  # Use the GPT-4 turbo model (replace if needed)
                messages=[
                    {"role": "system", "content": "You are a helpful assistant for questions about student events and activities at Universiti Teknologi Malaysia (UTM). I have the latest event updates, announcements, and schedules in UTM."},
                    {"role": "user", "content": user_message}
                ],
                max_tokens=1000,
                temperature=0.7
            )
            chat_response = response.choices[0].message.content.strip()
            chat_response = chat_response.replace('\n', '<br>')
            #chat_response = response.choices[0]
            #print("Debug General AI Response:\n", chat_response)
            return jsonify({'response': chat_response})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

def format_activities(activities):
  """Formats activity information into a string with newlines."""
  activity_string = ""
  for activity in activities:
    activity_string += f"- {activity['activity_name']} by {activity['club_society']}: {activity['description']}\n"
    activity_string += f"  Date: {activity['date']}, Time: {activity['time']}\n"
    activity_string += f"  Location: {activity['location']}\n"
    activity_string += f"  Registration: {activity['registration_link']}\n\n"
  return activity_string.strip()  # Remove trailing newline

if __name__ == '__main__':
    app.run(debug=True)